
import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Layout } from "@/components/layout";
import Dashboard from "@/pages/dashboard";
import Expenses from "@/pages/expenses";
import AddExpense from "@/pages/add-expense";
import Payments from "@/pages/payments";
import AddPayment from "@/pages/add-payment";
import Summary from "@/pages/summary";
import Members from "@/pages/members";
import NotFound from "@/pages/not-found";

const queryClient = new QueryClient({
defaultOptions: { queries: { refetchOnWindowFocus: false, staleTime: 5 * 60 * 1000, retry: 1 } },
});

function Router() {
return (
<Layout>
<Switch>
<Route path="/" component={Dashboard} />
<Route path="/expenses" component={Expenses} />
<Route path="/expenses/new" component={AddExpense} />
<Route path="/payments" component={Payments} />
<Route path="/payments/new" component={AddPayment} />
<Route path="/summary" component={Summary} />
<Route path="/members" component={Members} />
<Route component={NotFound} />
</Switch>
</Layout>
);
}

export default function App() {
return (
<QueryClientProvider client={queryClient}>
<TooltipProvider>
<WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
<Router />
</WouterRouter>
<Toaster />
</TooltipProvider>
</QueryClientProvider>
);
}
