
import { Router } from "express";
import { db } from "@workspace/db";
import { membersTable } from "@workspace/db/schema";
import { eq } from "drizzle-orm";
import { CreateMemberBody, DeleteMemberParams } from "@workspace/api-zod";

const router = Router();

router.get("/members", async (_req, res) => {
const members = await db.select().from(membersTable).orderBy(membersTable.id);
res.json(members);
});

router.post("/members", async (req, res) => {
const body = CreateMemberBody.parse(req.body);
const [member] = await db.insert(membersTable).values({ name: body.name }).returning();
res.status(201).json(member);
});

router.delete("/members/:id", async (req, res) => {
const { id } = DeleteMemberParams.parse({ id: Number(req.params.id) });
await db.delete(membersTable).where(eq(membersTable.id, id));
res.json({ success: true, message: "Member deleted successfully" });
});

export default router;
