
import { pgTable, serial, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { expensesTable } from "./expenses";
import { membersTable } from "./members";

export const attendanceTable = pgTable("attendance", {
id: serial("id").primaryKey(),
expenseId: integer("expense_id")
.notNull()
.references(() => expensesTable.id, { onDelete: "cascade" }),
memberId: integer("member_id")
.notNull()
.references(() => membersTable.id, { onDelete: "cascade" }),
present: boolean("present").notNull().default(false),
});

export const insertAttendanceSchema = createInsertSchema(attendanceTable).omit({ id: true });
export type InsertAttendance = z.infer<typeof insertAttendanceSchema>;
export type Attendance = typeof attendanceTable.$inferSelect;
