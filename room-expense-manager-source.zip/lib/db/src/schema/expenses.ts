
import { pgTable, serial, text, numeric, date } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const expensesTable = pgTable("expenses", {
id: serial("id").primaryKey(),
date: date("date").notNull(),
expenseName: text("expense_name").notNull(),
totalExpense: numeric("total_expense", { precision: 10, scale: 2 }).notNull(),
category: text("category"),
});

export const insertExpenseSchema = createInsertSchema(expensesTable).omit({ id: true });
export type InsertExpense = z.infer<typeof insertExpenseSchema>;
export type Expense = typeof expensesTable.$inferSelect;
