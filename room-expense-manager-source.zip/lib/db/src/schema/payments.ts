
import { pgTable, serial, integer, numeric } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { expensesTable } from "./expenses";
import { membersTable } from "./members";

export const paymentsTable = pgTable("payments", {
id: serial("id").primaryKey(),
expenseId: integer("expense_id").references(() => expensesTable.id, { onDelete: "cascade" }),
paidByMemberId: integer("paid_by_member_id")
.notNull()
.references(() => membersTable.id, { onDelete: "cascade" }),
amount: numeric("amount", { precision: 10, scale: 2 }).notNull(),
});

export const insertPaymentSchema = createInsertSchema(paymentsTable).omit({ id: true });
export type InsertPayment = z.infer<typeof insertPaymentSchema>;
export type Payment = typeof paymentsTable.$inferSelect;
